
package shubham;

import java.util.Calendar;
import java.util.GregorianCalendar;
import javax.swing.JOptionPane;

public class Acc_Created extends javax.swing.JFrame {int timeRun = 0;
int xM, yM;

    public Acc_Created() {
        initComponents();
        
        
    }
    public Acc_Created (int y)
    {
        initComponents();
        new Thread()
        {
            @Override
            public void run()
            {
                while(timeRun==0)
                {
                    Calendar cal = new GregorianCalendar();
                    
                    
                    int hour = cal.get(Calendar.HOUR);
                    int min = cal.get(Calendar.MINUTE);
                    int sec = cal.get(Calendar.SECOND);
                    int ap = cal.get(Calendar.AM_PM);
                    String d = "",c = "",b = "",a = "";
                    if(ap==0) d="AM";else d="PM";
                    if(sec<10) c="0"+sec;else c=""+sec;
                    if(min<10) b="0"+min;else b=""+min;
                    if(hour<10) a="0"+hour;else a=""+hour;
                    if(hour==0) a="12";
                    
                    Clock.setText(""+a+":"+b+":"+c+" "+d);
                }
            }
        }.start();
        accno.setText("Your account number is - "+y);
        
    
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        cut = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        accno = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        Clock = new javax.swing.JLabel();
        minimize = new javax.swing.JButton();
        drag = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBounds(new java.awt.Rectangle(200, 70, 0, 0));
        setMinimumSize(new java.awt.Dimension(1000, 600));
        setUndecorated(true);
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });
        getContentPane().setLayout(null);

        cut.setIcon(new javax.swing.ImageIcon(getClass().getResource("/shubham/close.png"))); // NOI18N
        cut.setBorder(null);
        cut.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        cut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cutActionPerformed(evt);
            }
        });
        getContentPane().add(cut);
        cut.setBounds(950, 10, 40, 20);

        jButton1.setText("View my Account");
        jButton1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(630, 400, 170, 50);

        jButton2.setText("Take me to the home page");
        jButton2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2);
        jButton2.setBounds(140, 400, 180, 50);

        accno.setFont(new java.awt.Font("Segoe UI Light", 0, 18)); // NOI18N
        accno.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        getContentPane().add(accno);
        accno.setBounds(270, 250, 460, 40);

        jLabel2.setFont(new java.awt.Font("Segoe UI Light", 0, 18)); // NOI18N
        jLabel2.setText("Congratulations! Your Account has been opened successfully");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(270, 210, 470, 50);

        Clock.setFont(new java.awt.Font("Segoe UI Light", 0, 20)); // NOI18N
        Clock.setForeground(new java.awt.Color(153, 0, 102));
        getContentPane().add(Clock);
        Clock.setBounds(740, 0, 140, 40);

        minimize.setText("_");
        minimize.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                minimizeActionPerformed(evt);
            }
        });
        getContentPane().add(minimize);
        minimize.setBounds(900, 10, 40, 20);

        drag.setBackground(new java.awt.Color(0, 0, 0));
        drag.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                dragMouseDragged(evt);
            }
        });
        drag.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                dragMousePressed(evt);
            }
        });
        getContentPane().add(drag);
        drag.setBounds(-10, 0, 1010, 40);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void cutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cutActionPerformed
        int q = JOptionPane.showConfirmDialog(null, "Do you want to exit");
        if(q==JOptionPane.YES_OPTION)
        {System.exit(0);}
    }//GEN-LAST:event_cutActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        new Face_1().setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        new Log_in().setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void minimizeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_minimizeActionPerformed
        this.setState(Acc_Created.ICONIFIED);
    }//GEN-LAST:event_minimizeActionPerformed

    private void dragMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dragMouseDragged
        int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();
        this.setLocation(x-xM,y-yM);
    }//GEN-LAST:event_dragMouseDragged

    private void dragMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dragMousePressed
        xM=evt.getX();
        yM=evt.getY();
    }//GEN-LAST:event_dragMousePressed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
for(double i = 0.0; i<=1.0; i+=0.1)
{
    String v = i+"F";
    float F = Float.valueOf(v);
    this.setOpacity(F);
    try
    {
        Thread.sleep(100);
    }
    catch(Exception e)
    {
        
    }
    
}
    }//GEN-LAST:event_formWindowOpened

    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Acc_Created.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Acc_Created.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Acc_Created.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Acc_Created.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Acc_Created().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Clock;
    private javax.swing.JLabel accno;
    private javax.swing.JButton cut;
    private javax.swing.JLabel drag;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JButton minimize;
    // End of variables declaration//GEN-END:variables
}
