
package shubham;


import java.util.*;
import javax.swing.*;
import java.sql.*;


public class Check_Balance extends javax.swing.JFrame {
int timeRun = 0;
int xM, yM;
String tp="";
Statement stmt=null;
    ResultSet rs=null;
    Connection conn=null;

    public Check_Balance() {
        initComponents(); 
    }
    
    public Check_Balance(String h)
    {
        initComponents();new Thread()
        {
            @Override
            public void run()
            {
                while(timeRun==0)
                {
                    Calendar cal = new GregorianCalendar();
                    
                    
                    int hour = cal.get(Calendar.HOUR);
                    int min = cal.get(Calendar.MINUTE);
                    int sec = cal.get(Calendar.SECOND);
                    int ap = cal.get(Calendar.AM_PM);
                    String d = "",c = "",b = "",a = "";
                    if(ap==0) d="AM";else d="PM";
                    if(sec<10) c="0"+sec;else c=""+sec;
                    if(min<10) b="0"+min;else b=""+min;
                    if(hour<10) a="0"+hour;else a=""+hour;
                    if(hour==0) a="12";
                    
                    Clock.setText(""+a+":"+b+":"+c+" "+d);
                }
            }
        }.start();
        tp=h;
        

             try
        {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            conn=(Connection)DriverManager.getConnection("jdbc:mysql://localhost:3306/bank","root","jermels");
            String query = "SELECT * FROM customer where Username = '"+tp+"';";
            stmt=conn.createStatement();
            rs=stmt.executeQuery(query);
            if(rs.next())
            {
               rupee.setText(""+rs.getDouble("AccountBalance"));
               new Account(tp).setVisible(true);
                this.setVisible(false);
               
            }
        }

        catch(Exception e)
        {
            JOptionPane.showMessageDialog(this,e.getMessage());
            e.printStackTrace();

        }
    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        cut = new javax.swing.JButton();
        back = new javax.swing.JButton();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        Clock = new javax.swing.JLabel();
        minimize = new javax.swing.JButton();
        rupee = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        drag = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1000, 600));
        setUndecorated(true);
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });
        getContentPane().setLayout(null);

        cut.setIcon(new javax.swing.ImageIcon(getClass().getResource("/shubham/close.png"))); // NOI18N
        cut.setBorder(null);
        cut.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        cut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cutActionPerformed(evt);
            }
        });
        getContentPane().add(cut);
        cut.setBounds(950, 10, 40, 20);

        back.setIcon(new javax.swing.ImageIcon(getClass().getResource("/shubham/back.jpg"))); // NOI18N
        back.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        back.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backActionPerformed(evt);
            }
        });
        getContentPane().add(back);
        back.setBounds(50, 50, 90, 40);

        jLabel20.setFont(new java.awt.Font("Segoe UI Light", 0, 24)); // NOI18N
        jLabel20.setText("Account Balance");
        getContentPane().add(jLabel20);
        jLabel20.setBounds(170, 30, 240, 40);

        jLabel21.setFont(new java.awt.Font("Segoe UI Light", 0, 14)); // NOI18N
        jLabel21.setText("Hi, your balance is shown below in INR.");
        getContentPane().add(jLabel21);
        jLabel21.setBounds(170, 60, 450, 40);

        Clock.setFont(new java.awt.Font("Segoe UI Light", 0, 20)); // NOI18N
        Clock.setForeground(new java.awt.Color(153, 0, 102));
        getContentPane().add(Clock);
        Clock.setBounds(740, 0, 140, 40);

        minimize.setText("_");
        minimize.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                minimizeActionPerformed(evt);
            }
        });
        getContentPane().add(minimize);
        minimize.setBounds(900, 10, 40, 20);

        rupee.setFont(new java.awt.Font("Segoe UI Light", 0, 48)); // NOI18N
        rupee.setOpaque(true);
        getContentPane().add(rupee);
        rupee.setBounds(430, 250, 250, 80);

        jLabel18.setFont(new java.awt.Font("Rupee Foradian", 0, 48)); // NOI18N
        jLabel18.setText("`");
        getContentPane().add(jLabel18);
        jLabel18.setBounds(390, 250, 40, 80);

        drag.setBackground(new java.awt.Color(0, 0, 0));
        drag.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                dragMouseDragged(evt);
            }
        });
        drag.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                dragMousePressed(evt);
            }
        });
        getContentPane().add(drag);
        drag.setBounds(-10, 0, 1010, 40);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void cutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cutActionPerformed
        int q = JOptionPane.showConfirmDialog(null, "Do you want to exit");
        if(q==JOptionPane.YES_OPTION)
        {System.exit(0);}
    }//GEN-LAST:event_cutActionPerformed

    private void backActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backActionPerformed
        new Account(tp).setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_backActionPerformed

    private void minimizeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_minimizeActionPerformed
        this.setState(Check_Balance.ICONIFIED);
    }//GEN-LAST:event_minimizeActionPerformed

    private void dragMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dragMouseDragged
        int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();
        this.setLocation(x-xM,y-yM);
    }//GEN-LAST:event_dragMouseDragged

    private void dragMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dragMousePressed
        xM=evt.getX();
        yM=evt.getY();
    }//GEN-LAST:event_dragMousePressed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
for(double i = 0.0; i<=1.0; i+=0.1)
{
    String v = i+"F";
    float F = Float.valueOf(v);
    this.setOpacity(F);
    try
    {
        Thread.sleep(100);
    }
    catch(Exception e)
    {
        
    }
    
}
    }//GEN-LAST:event_formWindowOpened

    public static void main(String args[]) {
      
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Check_Balance.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Check_Balance.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Check_Balance.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Check_Balance.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>


        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Check_Balance().setVisible(true);
                
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Clock;
    private javax.swing.JButton back;
    private javax.swing.JButton cut;
    private javax.swing.JLabel drag;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JButton minimize;
    private javax.swing.JLabel rupee;
    // End of variables declaration//GEN-END:variables
}
