
package shubham;


import javax.swing.*;
import java.sql.*;
import java.util.Calendar;
import java.util.GregorianCalendar;


public class Forgot_Password extends javax.swing.JFrame {

    int xM, yM;
Statement stmt=null;
    ResultSet rs=null;
    Connection conn=null;
int timeRun = 0;
    public Forgot_Password() {
        initComponents();
        new Thread()
        {
            @Override
            public void run()
            {
                while(timeRun==0)
                {
                    Calendar cal = new GregorianCalendar();
                    
                    
                    int hour = cal.get(Calendar.HOUR);
                    int min = cal.get(Calendar.MINUTE);
                    int sec = cal.get(Calendar.SECOND);
                    int ap = cal.get(Calendar.AM_PM);
                    String d = "",c = "",b = "",a = "";
                    if(ap==0) d="AM";else d="PM";
                    if(sec<10) c="0"+sec;else c=""+sec;
                    if(min<10) b="0"+min;else b=""+min;
                    if(hour<10) a="0"+hour;else a=""+hour;
                    if(hour==0) a="12";
                    
                    Clock.setText(""+a+":"+b+":"+c+" "+d);
                }
            }
        }.start();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        cut = new javax.swing.JButton();
        back = new javax.swing.JButton();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        Clock = new javax.swing.JLabel();
        minimize = new javax.swing.JButton();
        drag = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        user = new javax.swing.JTextField();
        name1 = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        name2 = new javax.swing.JTextField();
        name3 = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        aadhar = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        pswrd = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1000, 600));
        setUndecorated(true);
        setPreferredSize(new java.awt.Dimension(1003, 403));
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });
        getContentPane().setLayout(null);

        cut.setIcon(new javax.swing.ImageIcon(getClass().getResource("/shubham/close.png"))); // NOI18N
        cut.setBorder(null);
        cut.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        cut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cutActionPerformed(evt);
            }
        });
        getContentPane().add(cut);
        cut.setBounds(950, 10, 40, 20);

        back.setIcon(new javax.swing.ImageIcon(getClass().getResource("/shubham/back.jpg"))); // NOI18N
        back.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backActionPerformed(evt);
            }
        });
        getContentPane().add(back);
        back.setBounds(50, 50, 90, 40);

        jLabel20.setFont(new java.awt.Font("Segoe UI Light", 0, 24)); // NOI18N
        jLabel20.setText("Forgot Password?");
        getContentPane().add(jLabel20);
        jLabel20.setBounds(170, 30, 240, 40);

        jLabel21.setFont(new java.awt.Font("Segoe UI Light", 0, 14)); // NOI18N
        jLabel21.setText("Axis Bank offers a less worry feature if you forget your password");
        getContentPane().add(jLabel21);
        jLabel21.setBounds(170, 60, 450, 40);

        jLabel22.setFont(new java.awt.Font("Segoe UI Light", 0, 14)); // NOI18N
        jLabel22.setText("Simply complete a few verification steps and click on the corresponding button below and get access to your account instantly.");
        getContentPane().add(jLabel22);
        jLabel22.setBounds(170, 90, 780, 30);

        Clock.setFont(new java.awt.Font("Segoe UI Light", 0, 20)); // NOI18N
        Clock.setForeground(new java.awt.Color(153, 0, 102));
        getContentPane().add(Clock);
        Clock.setBounds(740, 0, 140, 40);

        minimize.setText("_");
        minimize.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                minimizeActionPerformed(evt);
            }
        });
        getContentPane().add(minimize);
        minimize.setBounds(900, 10, 40, 20);

        drag.setBackground(new java.awt.Color(0, 0, 0));
        drag.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                dragMouseDragged(evt);
            }
        });
        drag.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                dragMousePressed(evt);
            }
        });
        getContentPane().add(drag);
        drag.setBounds(-10, 0, 1010, 40);

        jLabel1.setText("Enter your username");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(570, 220, 130, 20);
        getContentPane().add(user);
        user.setBounds(570, 240, 200, 40);
        getContentPane().add(name1);
        name1.setBounds(230, 160, 180, 40);

        jLabel2.setText("First Name");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(230, 140, 120, 20);
        getContentPane().add(name2);
        name2.setBounds(440, 160, 170, 40);
        getContentPane().add(name3);
        name3.setBounds(640, 160, 170, 40);

        jLabel3.setText("Middle Name");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(440, 140, 120, 20);

        jLabel4.setText("Last Name");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(640, 140, 80, 20);

        jLabel7.setText("Aadhar Number");
        getContentPane().add(jLabel7);
        jLabel7.setBounds(230, 220, 90, 20);
        getContentPane().add(aadhar);
        aadhar.setBounds(230, 240, 310, 40);

        jLabel5.setText("Your Password");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(440, 420, 130, 20);

        pswrd.setEditable(false);
        pswrd.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        getContentPane().add(pswrd);
        pswrd.setBounds(350, 440, 270, 40);

        jButton1.setText("Find");
        jButton1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(470, 330, 53, 32);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void cutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cutActionPerformed
        int q = JOptionPane.showConfirmDialog(null, "Do you want to exit");
        if(q==JOptionPane.YES_OPTION)
        {System.exit(0);}
    }//GEN-LAST:event_cutActionPerformed

    private void backActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backActionPerformed
        new Log_in().setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_backActionPerformed

    private void minimizeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_minimizeActionPerformed
        this.setState(Forgot_Password.ICONIFIED);
    }//GEN-LAST:event_minimizeActionPerformed

    private void dragMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dragMouseDragged
        int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();
        this.setLocation(x-xM,y-yM);
    }//GEN-LAST:event_dragMouseDragged

    private void dragMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dragMousePressed
        xM=evt.getX();
        yM=evt.getY();
    }//GEN-LAST:event_dragMousePressed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try
        {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            conn=(Connection)DriverManager.getConnection("jdbc:mysql://localhost:3306/bank","root","jermels");
            String query = "SELECT * FROM customer where FirstName = '"+name1.getText()+"' AND MiddleName = '"+name2.getText()+"' AND LastName = '"+name3.getText()+"' AND Aadhar = '"+aadhar.getText()+"' AND Username='"+user.getText()+"';";
            stmt=conn.createStatement();
            rs=stmt.executeQuery(query);
            if(rs.next())
            {
                pswrd.setText(rs.getString("Password"));
            }
            
        }
        
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(this,e.getMessage());
          e.printStackTrace();

        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
for(double i = 0.0; i<=1.0; i+=0.1)
{
    String v = i+"F";
    float F = Float.valueOf(v);
    this.setOpacity(F);
    try
    {
        Thread.sleep(100);
    }
    catch(Exception e)
    {
        
    }
    
}
    }//GEN-LAST:event_formWindowOpened

    
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Forgot_Password().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Clock;
    private javax.swing.JTextField aadhar;
    private javax.swing.JButton back;
    private javax.swing.JButton cut;
    private javax.swing.JLabel drag;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JButton minimize;
    private javax.swing.JTextField name1;
    private javax.swing.JTextField name2;
    private javax.swing.JTextField name3;
    private javax.swing.JTextField pswrd;
    private javax.swing.JTextField user;
    // End of variables declaration//GEN-END:variables
}
