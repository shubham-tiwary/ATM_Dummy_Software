
package shubham;

import AppPackage.AnimationClass;
import java.util.Calendar;
import java.util.GregorianCalendar;
import javax.swing.JOptionPane;
import java.sql.*;


public class Fund_Transfer extends javax.swing.JFrame {
int timeRun = 0;
int xM, yM;
Statement stmt=null;
    ResultSet rs=null, rs1=null, rs2=null;
    Connection conn=null;
String tmp="";

    public Fund_Transfer() {
        initComponents();
         
    }
    
    public Fund_Transfer(String h)
    {
        initComponents();
        new Thread()
        {
            @Override
            public void run()
            {
                while(timeRun==0)
                {
                    Calendar cal = new GregorianCalendar();
                    
                    
                    int hour = cal.get(Calendar.HOUR);
                    int min = cal.get(Calendar.MINUTE);
                    int sec = cal.get(Calendar.SECOND);
                    int ap = cal.get(Calendar.AM_PM);
                    String d = "",c = "",b = "",a = "";
                    if(ap==0) d="AM";else d="PM";
                    if(sec<10) c="0"+sec;else c=""+sec;
                    if(min<10) b="0"+min;else b=""+min;
                    if(hour<10) a="0"+hour;else a=""+hour;
                    if(hour==0) a="12";
                    
                    Clock.setText(""+a+":"+b+":"+c+" "+d);
                }
            }
        }.start();
        tmp=h;
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel18 = new javax.swing.JLabel();
        cut = new javax.swing.JButton();
        back = new javax.swing.JButton();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        Clock = new javax.swing.JLabel();
        minimize = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        acntno = new javax.swing.JTextField();
        amnt = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        namee = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        drag = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1000, 600));
        setUndecorated(true);
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });
        getContentPane().setLayout(null);

        jLabel18.setFont(new java.awt.Font("Rupee Foradian", 0, 18)); // NOI18N
        jLabel18.setText("`");
        getContentPane().add(jLabel18);
        jLabel18.setBounds(430, 290, 20, 40);

        cut.setIcon(new javax.swing.ImageIcon(getClass().getResource("/shubham/close.png"))); // NOI18N
        cut.setBorder(null);
        cut.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        cut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cutActionPerformed(evt);
            }
        });
        getContentPane().add(cut);
        cut.setBounds(950, 10, 40, 20);

        back.setIcon(new javax.swing.ImageIcon(getClass().getResource("/shubham/back.jpg"))); // NOI18N
        back.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backActionPerformed(evt);
            }
        });
        getContentPane().add(back);
        back.setBounds(50, 50, 80, 40);

        jLabel20.setFont(new java.awt.Font("Segoe UI Light", 0, 24)); // NOI18N
        jLabel20.setText("Fund Transfer");
        getContentPane().add(jLabel20);
        jLabel20.setBounds(170, 30, 240, 40);

        jLabel21.setFont(new java.awt.Font("Segoe UI Light", 0, 14)); // NOI18N
        jLabel21.setText("Now you can transfer funds easily to any Axis Bank Customer.");
        getContentPane().add(jLabel21);
        jLabel21.setBounds(170, 60, 450, 40);

        jLabel22.setFont(new java.awt.Font("Segoe UI Light", 0, 14)); // NOI18N
        jLabel22.setText("Simply enter the account number and click on the corresponding button below and get fund transferred instantly.");
        getContentPane().add(jLabel22);
        jLabel22.setBounds(170, 90, 780, 30);

        Clock.setFont(new java.awt.Font("Segoe UI Light", 0, 20)); // NOI18N
        Clock.setForeground(new java.awt.Color(153, 0, 102));
        getContentPane().add(Clock);
        Clock.setBounds(740, 0, 140, 40);

        minimize.setText("_");
        minimize.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                minimizeActionPerformed(evt);
            }
        });
        getContentPane().add(minimize);
        minimize.setBounds(900, 10, 40, 20);

        jLabel1.setText("Enter the Amount");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(320, 290, 100, 40);
        getContentPane().add(acntno);
        acntno.setBounds(450, 180, 210, 40);
        getContentPane().add(amnt);
        amnt.setBounds(450, 290, 210, 40);

        jLabel4.setText("Enter the Account Number");
        jLabel4.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        getContentPane().add(jLabel4);
        jLabel4.setBounds(270, 180, 160, 40);

        namee.setFont(new java.awt.Font("Segoe UI Light", 0, 13)); // NOI18N
        namee.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        namee.setText("Account number of Abcd Efgh");
        namee.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        getContentPane().add(namee);
        namee.setBounds(450, 190, 210, 20);

        jButton1.setText("Transfer");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(500, 390, 120, 40);

        drag.setBackground(new java.awt.Color(0, 0, 0));
        drag.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                dragMouseDragged(evt);
            }
        });
        drag.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                dragMousePressed(evt);
            }
        });
        getContentPane().add(drag);
        drag.setBounds(-10, 0, 1010, 40);

        jButton2.setText("Search");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2);
        jButton2.setBounds(670, 190, 77, 32);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void cutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cutActionPerformed
        int q = JOptionPane.showConfirmDialog(null, "Do you want to exit");
        if(q==JOptionPane.YES_OPTION)
        {System.exit(0);}
    }//GEN-LAST:event_cutActionPerformed

    private void backActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backActionPerformed
        new Account(tmp).setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_backActionPerformed

    private void minimizeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_minimizeActionPerformed
        this.setState(Fund_Transfer.ICONIFIED);
    }//GEN-LAST:event_minimizeActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
              AnimationClass ac = new AnimationClass();
               int opn=JOptionPane.showConfirmDialog(null, "Want to transfer?");
               
               if(opn==JOptionPane.YES_OPTION)
               {
                   try
                   {
                       Class.forName("com.mysql.jdbc.Driver").newInstance();
                       conn=(Connection)DriverManager.getConnection("jdbc:mysql://localhost:3306/bank","root","jermels");
                       stmt=conn.createStatement();
                       String qu="UPDATE customer set AccountBalance=AccountBalance+"+Double.parseDouble(amnt.getText())+" where Account_num = "+Integer.parseInt(acntno.getText())+";";
                       stmt.executeUpdate(qu);
                       String qu2 ="UPDATE customer set AccountBalance=AccountBalance-"+Double.parseDouble(amnt.getText())+" where Username = '"+tmp+"';";
                       stmt.executeUpdate(qu2);
                       JOptionPane.showMessageDialog(null,"Transfer Success!!");
                                   
                   }
                   catch (Exception e)
                   {
                       JOptionPane.showMessageDialog(null, e);
                   }
               }

            
            
        


        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void dragMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dragMouseDragged
        int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();
        this.setLocation(x-xM,y-yM);
    }//GEN-LAST:event_dragMouseDragged

    private void dragMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dragMousePressed
        xM=evt.getX();
        yM=evt.getY();
    }//GEN-LAST:event_dragMousePressed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        AnimationClass ac = new AnimationClass();
      
            
    
        try
        {
             Class.forName("com.mysql.jdbc.Driver").newInstance();
            conn=(Connection)DriverManager.getConnection("jdbc:mysql://localhost:3306/bank","root","jermels");
            stmt=conn.createStatement();
            String query = "SELECT * FROM customer where Account_num = "+acntno.getText()+";";
            rs=stmt.executeQuery(query);
            
            if(rs.next())
            {
                namee.setText("Account number of "+rs.getString("FirstName")+" "+rs.getString("MiddleName")+" "+rs.getString("LastName"));
               ac.jLabelYDown(190, 230, 10, 5, namee);
            }
            else
            {
                namee.setText("No such records found");
                ac.jLabelYDown(190, 230, 10, 5, namee);
            }
            
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null,"Error!!");
            namee.setText("Oops!! Blanks are empty");
            ac.jLabelYDown(190, 230, 10, 5, namee);
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
for(double i = 0.0; i<=1.0; i+=0.1)
{
    String v = i+"F";
    float F = Float.valueOf(v);
    this.setOpacity(F);
    try
    {
        Thread.sleep(100);
    }
    catch(Exception e)
    {
        
    }
    
}
    }//GEN-LAST:event_formWindowOpened

    
    public static void main(String args[]) {
       
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Fund_Transfer.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Fund_Transfer.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Fund_Transfer.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Fund_Transfer.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

       
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Fund_Transfer().setVisible(true);
                
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Clock;
    private javax.swing.JTextField acntno;
    private javax.swing.JTextField amnt;
    private javax.swing.JButton back;
    private javax.swing.JButton cut;
    private javax.swing.JLabel drag;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JButton minimize;
    private javax.swing.JLabel namee;
    // End of variables declaration//GEN-END:variables
}
