
package shubham;


import java.sql.*;
import java.util.Calendar;
import java.util.GregorianCalendar;
import javax.swing.JOptionPane;


public class Update_Details extends javax.swing.JFrame {
int timeRun = 0;
 int xM, yM;Statement stmt=null;
    ResultSet rs=null;
    Connection conn=null;
    String u="";
  
    public Update_Details() {
        initComponents();
    }
    public Update_Details(String t) {
        initComponents();
         new Thread()
        {
            public void run()
            {
                while(timeRun==0)
                {
                    Calendar cal = new GregorianCalendar();
                    
                    
                    int hour = cal.get(Calendar.HOUR);
                    int min = cal.get(Calendar.MINUTE);
                    int sec = cal.get(Calendar.SECOND);
                    int ap = cal.get(Calendar.AM_PM);
                    String d = "",c = "",b = "",a = "";
                    if(ap==0) d="AM";else d="PM";
                    if(sec<10) c="0"+sec;else c=""+sec;
                    if(min<10) b="0"+min;else b=""+min;
                    if(hour<10) a="0"+hour;else a=""+hour;
                    if(hour==0) a="12";
                    
                    Clock.setText(""+a+":"+b+":"+c+" "+d);
                }
            }
        }.start();
        u=t;
        try
        {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            conn=(Connection)DriverManager.getConnection("jdbc:mysql://localhost:3306/bank","root","jermels");
            String query = "SELECT * FROM customer where Username = '"+t+"';";
            stmt=conn.createStatement();
            rs=stmt.executeQuery(query);
            if(rs.next())
            {
                name1.setText(rs.getString("FirstName"));
                name2.setText(rs.getString("MiddleName"));
                name3.setText(rs.getString("LastName"));
                gender.setSelectedItem(rs.getString("Gender"));
                father.setText(rs.getString("Father"));
                mother.setText(rs.getString("Mother"));
                address.setText(rs.getString("Address"));
                dob.setText(rs.getString("DOB"));
                state.setSelectedItem(rs.getString("State"));
                mobile.setText(rs.getString("Mobile"));
                pincode.setText(rs.getString("Pincode"));
                aadhar.setText(rs.getString("Aadhar"));
                email.setText(rs.getString("Email"));
                username.setText(rs.getString("Username"));
                pass.setText(rs.getString("Password"));
                acc.setText(rs.getString("Account_num"));
            }
            
        }
        
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(this,e.getMessage());
          e.printStackTrace();

        }
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        cut = new javax.swing.JButton();
        back = new javax.swing.JButton();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        Clock = new javax.swing.JLabel();
        minimize = new javax.swing.JButton();
        drag = new javax.swing.JLabel();
        name1 = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        name2 = new javax.swing.JTextField();
        name3 = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        address = new javax.swing.JTextArea();
        jLabel4 = new javax.swing.JLabel();
        mobile = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        state = new javax.swing.JComboBox<>();
        jLabel6 = new javax.swing.JLabel();
        aadhar = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        gender = new javax.swing.JComboBox<>();
        jLabel9 = new javax.swing.JLabel();
        dob = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        email = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        father = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        mother = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        pincode = new javax.swing.JTextField();
        username = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        pass = new javax.swing.JTextField();
        acc = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1000, 600));
        setUndecorated(true);
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });
        getContentPane().setLayout(null);

        cut.setIcon(new javax.swing.ImageIcon(getClass().getResource("/shubham/close.png"))); // NOI18N
        cut.setBorder(null);
        cut.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        cut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cutActionPerformed(evt);
            }
        });
        getContentPane().add(cut);
        cut.setBounds(950, 10, 40, 20);

        back.setIcon(new javax.swing.ImageIcon(getClass().getResource("/shubham/back.jpg"))); // NOI18N
        back.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backActionPerformed(evt);
            }
        });
        getContentPane().add(back);
        back.setBounds(50, 50, 80, 40);

        jLabel20.setFont(new java.awt.Font("Segoe UI Light", 0, 24)); // NOI18N
        jLabel20.setText("Update Details");
        getContentPane().add(jLabel20);
        jLabel20.setBounds(170, 30, 240, 40);

        jLabel21.setFont(new java.awt.Font("Segoe UI Light", 0, 14)); // NOI18N
        jLabel21.setText("Axis Bank offers a instant update feature to you");
        getContentPane().add(jLabel21);
        jLabel21.setBounds(170, 60, 450, 40);

        jLabel22.setFont(new java.awt.Font("Segoe UI Light", 0, 14)); // NOI18N
        jLabel22.setText("Simply complete the updation and click on the corresponding button below and get your account updated instantly.");
        getContentPane().add(jLabel22);
        jLabel22.setBounds(170, 90, 780, 30);

        Clock.setFont(new java.awt.Font("Segoe UI Light", 0, 20)); // NOI18N
        Clock.setForeground(new java.awt.Color(153, 0, 102));
        getContentPane().add(Clock);
        Clock.setBounds(740, 0, 140, 40);

        minimize.setText("_");
        minimize.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                minimizeActionPerformed(evt);
            }
        });
        getContentPane().add(minimize);
        minimize.setBounds(900, 10, 40, 20);

        drag.setBackground(new java.awt.Color(0, 0, 0));
        drag.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                dragMouseDragged(evt);
            }
        });
        drag.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                dragMousePressed(evt);
            }
        });
        getContentPane().add(drag);
        drag.setBounds(-10, 0, 1010, 40);
        getContentPane().add(name1);
        name1.setBounds(170, 150, 180, 40);

        jLabel1.setText("First Name");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(170, 130, 120, 20);
        getContentPane().add(name2);
        name2.setBounds(380, 150, 170, 40);
        getContentPane().add(name3);
        name3.setBounds(580, 150, 170, 40);

        jLabel2.setText("Middle Name");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(380, 130, 120, 20);

        jLabel3.setText("Last Name");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(580, 130, 80, 20);

        address.setColumns(20);
        address.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        address.setRows(5);
        jScrollPane1.setViewportView(address);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(170, 290, 290, 78);

        jLabel4.setText("Address");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(170, 270, 50, 20);

        mobile.setColumns(10);
        getContentPane().add(mobile);
        mobile.setBounds(480, 360, 160, 40);

        jLabel5.setText("Landline Number (7 digit)");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(480, 340, 150, 20);

        state.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Andaman & Nicobar Islands (UT)", "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chandigarh (UT)", "Chhattisgarh", "Dadra & Nagar Haveli", "Daman & Diu (UT)", "Delhi", "Goa", "Gujrat", "Haryana", "Himachal Pradesh", "Jammu & Kashmir", "Jharkhand", "Karnataka", "Kerala", "Lakshadweep (UT)", "Madhya Pradesh", "Maharastra", "Manipur", "Meghalaya", "Mizoram", "Nagaland", "Odisha", "Puducherry (UT)", "Punjab", "Rajasthan", "Sikkim", "Tamil Nadu", "Telangana", "Tripura", "Uttar Pradesh", "Uttrakhand", "West Bengal" }));
        state.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        getContentPane().add(state);
        state.setBounds(660, 310, 230, 26);

        jLabel6.setText("State");
        getContentPane().add(jLabel6);
        jLabel6.setBounds(660, 290, 40, 20);
        getContentPane().add(aadhar);
        aadhar.setBounds(170, 420, 270, 40);

        jLabel7.setText("Aadhar Number");
        getContentPane().add(jLabel7);
        jLabel7.setBounds(170, 400, 90, 20);

        jLabel8.setText("Gender");
        getContentPane().add(jLabel8);
        jLabel8.setBounds(760, 150, 60, 20);

        gender.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Male", "Female", "Others" }));
        gender.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        getContentPane().add(gender);
        gender.setBounds(760, 170, 90, 26);

        jLabel9.setText("Date of Birth");
        getContentPane().add(jLabel9);
        jLabel9.setBounds(490, 270, 80, 20);

        dob.setText("YYYY-MM-DD");
        getContentPane().add(dob);
        dob.setBounds(490, 290, 150, 40);

        jLabel10.setText("Nationality");
        getContentPane().add(jLabel10);
        jLabel10.setBounds(650, 200, 70, 16);

        jTextField2.setEditable(false);
        jTextField2.setText("INDIAN");
        jTextField2.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        getContentPane().add(jTextField2);
        jTextField2.setBounds(650, 220, 120, 40);
        getContentPane().add(email);
        email.setBounds(460, 420, 360, 40);

        jLabel11.setText("Email-ID");
        getContentPane().add(jLabel11);
        jLabel11.setBounds(460, 400, 50, 20);
        getContentPane().add(father);
        father.setBounds(170, 220, 220, 40);

        jLabel12.setText("Father's Name");
        getContentPane().add(jLabel12);
        jLabel12.setBounds(170, 200, 140, 16);
        getContentPane().add(mother);
        mother.setBounds(420, 220, 210, 40);

        jLabel13.setText("Mother's Name");
        getContentPane().add(jLabel13);
        jLabel13.setBounds(420, 200, 90, 20);

        jLabel14.setText("Pincode");
        getContentPane().add(jLabel14);
        jLabel14.setBounds(660, 340, 100, 16);
        getContentPane().add(pincode);
        pincode.setBounds(660, 360, 160, 40);
        getContentPane().add(username);
        username.setBounds(170, 490, 180, 40);

        jLabel15.setText("Username");
        getContentPane().add(jLabel15);
        jLabel15.setBounds(170, 470, 120, 20);

        jLabel16.setText("Account Number");
        getContentPane().add(jLabel16);
        jLabel16.setBounds(590, 470, 140, 20);

        jButton1.setText("Update");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(490, 560, 70, 32);
        getContentPane().add(pass);
        pass.setBounds(370, 490, 190, 40);

        acc.setEditable(false);
        getContentPane().add(acc);
        acc.setBounds(590, 490, 240, 40);

        jLabel17.setText("Password");
        getContentPane().add(jLabel17);
        jLabel17.setBounds(370, 470, 60, 20);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void cutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cutActionPerformed
        int q = JOptionPane.showConfirmDialog(null, "Do you want to exit");
        if(q==JOptionPane.YES_OPTION)
        {System.exit(0);}
    }//GEN-LAST:event_cutActionPerformed

    private void backActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backActionPerformed
        new Account(u).setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_backActionPerformed

    private void minimizeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_minimizeActionPerformed
        this.setState(Update_Details.ICONIFIED);
    }//GEN-LAST:event_minimizeActionPerformed

    private void dragMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dragMouseDragged
        int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();
        this.setLocation(x-xM,y-yM);
    }//GEN-LAST:event_dragMouseDragged

    private void dragMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dragMousePressed
        xM=evt.getX();
        yM=evt.getY();
    }//GEN-LAST:event_dragMousePressed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
try
        {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            conn=(Connection)DriverManager.getConnection("jdbc:mysql://localhost:3306/bank","root","jermels");
            String query = "UPDATE customer SET FirstName = '"+name1.getText()+"',MiddleName='"+name2.getText()+"',LastName='"+name3.getText()+"',Gender='"+gender.getSelectedItem()+"',Father='"+father.getText()+"',Mother='"+mother.getText()+"',Address='"+address.getText()+"',DOB='"+dob.getText()+"',State='"+state.getSelectedItem()+"',Mobile='"+Long.parseLong(mobile.getText())+"',Pincode='"+Integer.parseInt(pincode.getText())+"',Email='"+email.getText()+"',Username='"+username.getText()+"',Password='"+pass.getText()+"' WHERE Username = '"+u+"';";
            stmt=conn.createStatement();
            stmt.executeUpdate(query);
            
            JOptionPane.showMessageDialog(this,"Account Updated Successfully");
        }
        
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(this,e.getMessage());
          e.printStackTrace();

        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
for(double i = 0.0; i<=1.0; i+=0.1)
{
    String v = i+"F";
    float F = Float.valueOf(v);
    this.setOpacity(F);
    try
    {
        Thread.sleep(100);
    }
    catch(Exception e)
    {
        
    }
    
}
    }//GEN-LAST:event_formWindowOpened

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Update_Details.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Update_Details.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Update_Details.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Update_Details.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Update_Details().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Clock;
    private javax.swing.JTextField aadhar;
    private javax.swing.JTextField acc;
    private javax.swing.JTextArea address;
    private javax.swing.JButton back;
    private javax.swing.JButton cut;
    private javax.swing.JTextField dob;
    private javax.swing.JLabel drag;
    private javax.swing.JTextField email;
    private javax.swing.JTextField father;
    private javax.swing.JComboBox<String> gender;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JButton minimize;
    private javax.swing.JTextField mobile;
    private javax.swing.JTextField mother;
    private javax.swing.JTextField name1;
    private javax.swing.JTextField name2;
    private javax.swing.JTextField name3;
    private javax.swing.JTextField pass;
    private javax.swing.JTextField pincode;
    private javax.swing.JComboBox<String> state;
    private javax.swing.JTextField username;
    // End of variables declaration//GEN-END:variables
}
