
package shubham;

import java.sql.*;
import java.util.Calendar;
import java.util.GregorianCalendar;
import AppPackage.AnimationClass;
import javax.swing.*;


public class Account extends javax.swing.JFrame {
int timeRun = 0;    
int xM, yM;
Statement stmt=null;
    ResultSet rs=null;
    Connection conn=null;
    String temp="";
    
    
    public Account() {
        initComponents();
        
    }
    
    
    
    public Account(String nam)
    {
        initComponents();
        new Thread()
        {
            @Override
            public void run()
            {
                while(timeRun==0)
                {
                    Calendar cal = new GregorianCalendar();
                    
                    
                    int hour = cal.get(Calendar.HOUR);
                    int min = cal.get(Calendar.MINUTE);
                    int sec = cal.get(Calendar.SECOND);
                    int ap = cal.get(Calendar.AM_PM);
                    String d = "",c = "",b = "",a = "";
                    if(ap==0) d="AM";else d="PM";
                    if(sec<10) c="0"+sec;else c=""+sec;
                    if(min<10) b="0"+min;else b=""+min;
                    if(hour<10) a="0"+hour;else a=""+hour;
                    if(hour==0) a="12";
                    
                    Clock.setText(""+a+":"+b+":"+c+" "+d);
                }
            }
        }.start();
        temp=nam;
        try
        {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            conn=(Connection)DriverManager.getConnection("jdbc:mysql://localhost:3306/bank","root","jermels");
            String query = "SELECT * FROM customer where Username = '"+nam+"';";
            stmt=conn.createStatement();
            rs=stmt.executeQuery(query);
            if(rs.next())
            {
               nm.setText("Hi, "+rs.getString("FirstName"));
               
            }
        }

        catch(ClassNotFoundException | InstantiationException | IllegalAccessException | SQLException e)
        {
            JOptionPane.showMessageDialog(this,e.getMessage());

        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        updt_acc = new javax.swing.JButton();
        log_out = new javax.swing.JButton();
        acc_del = new javax.swing.JButton();
        stt = new javax.swing.JLabel();
        transfer = new javax.swing.JLabel();
        wthdrw = new javax.swing.JLabel();
        deposit = new javax.swing.JLabel();
        accbal = new javax.swing.JLabel();
        cut = new javax.swing.JButton();
        nm = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        settings = new javax.swing.JButton();
        Clock = new javax.swing.JLabel();
        minimize = new javax.swing.JButton();
        drag = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1000, 600));
        setUndecorated(true);
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });
        getContentPane().setLayout(null);

        updt_acc.setForeground(new java.awt.Color(255, 255, 255));
        updt_acc.setIcon(new javax.swing.ImageIcon(getClass().getResource("/shubham/black.jpg"))); // NOI18N
        updt_acc.setText("Update Details");
        updt_acc.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        updt_acc.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        updt_acc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updt_accActionPerformed(evt);
            }
        });
        getContentPane().add(updt_acc);
        updt_acc.setBounds(250, 600, 120, 50);

        log_out.setForeground(new java.awt.Color(255, 255, 255));
        log_out.setIcon(new javax.swing.ImageIcon(getClass().getResource("/shubham/black.jpg"))); // NOI18N
        log_out.setText("Log out");
        log_out.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        log_out.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        log_out.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                log_outActionPerformed(evt);
            }
        });
        getContentPane().add(log_out);
        log_out.setBounds(610, 680, 120, 50);

        acc_del.setForeground(new java.awt.Color(255, 255, 255));
        acc_del.setIcon(new javax.swing.ImageIcon(getClass().getResource("/shubham/black.jpg"))); // NOI18N
        acc_del.setText("Delete my Account");
        acc_del.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        acc_del.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        acc_del.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                acc_delActionPerformed(evt);
            }
        });
        getContentPane().add(acc_del);
        acc_del.setBounds(430, 640, 140, 50);

        stt.setBackground(new java.awt.Color(153, 153, 153));
        stt.setFont(new java.awt.Font("Segoe UI Light", 0, 30)); // NOI18N
        stt.setForeground(new java.awt.Color(255, 255, 255));
        stt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/shubham/stt.jpg"))); // NOI18N
        stt.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        stt.setOpaque(true);
        getContentPane().add(stt);
        stt.setBounds(1000, 140, 570, 340);

        transfer.setBackground(new java.awt.Color(153, 153, 153));
        transfer.setFont(new java.awt.Font("Segoe UI Light", 0, 24)); // NOI18N
        transfer.setForeground(new java.awt.Color(255, 255, 255));
        transfer.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        transfer.setIcon(new javax.swing.ImageIcon(getClass().getResource("/shubham/black.jpg"))); // NOI18N
        transfer.setText("Fund Transfer");
        transfer.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        transfer.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        transfer.setOpaque(true);
        transfer.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                transferMouseReleased(evt);
            }
        });
        getContentPane().add(transfer);
        transfer.setBounds(760, 430, 180, 40);

        wthdrw.setBackground(new java.awt.Color(153, 153, 153));
        wthdrw.setFont(new java.awt.Font("Segoe UI Light", 0, 24)); // NOI18N
        wthdrw.setForeground(new java.awt.Color(255, 255, 255));
        wthdrw.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        wthdrw.setIcon(new javax.swing.ImageIcon(getClass().getResource("/shubham/black.jpg"))); // NOI18N
        wthdrw.setText("Withdraw Cash");
        wthdrw.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        wthdrw.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        wthdrw.setOpaque(true);
        wthdrw.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                wthdrwMouseReleased(evt);
            }
        });
        getContentPane().add(wthdrw);
        wthdrw.setBounds(300, 430, 180, 40);

        deposit.setBackground(new java.awt.Color(153, 153, 153));
        deposit.setFont(new java.awt.Font("Segoe UI Light", 0, 24)); // NOI18N
        deposit.setForeground(new java.awt.Color(255, 255, 255));
        deposit.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        deposit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/shubham/black.jpg"))); // NOI18N
        deposit.setText("Deposit Cash");
        deposit.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        deposit.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        deposit.setOpaque(true);
        deposit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                depositMouseReleased(evt);
            }
        });
        getContentPane().add(deposit);
        deposit.setBounds(530, 430, 180, 40);

        accbal.setBackground(new java.awt.Color(153, 153, 153));
        accbal.setFont(new java.awt.Font("Segoe UI Light", 0, 24)); // NOI18N
        accbal.setForeground(new java.awt.Color(255, 255, 255));
        accbal.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        accbal.setIcon(new javax.swing.ImageIcon(getClass().getResource("/shubham/black.jpg"))); // NOI18N
        accbal.setText(" Account Balance");
        accbal.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        accbal.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        accbal.setOpaque(true);
        accbal.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                accbalMouseReleased(evt);
            }
        });
        getContentPane().add(accbal);
        accbal.setBounds(70, 430, 200, 40);

        cut.setIcon(new javax.swing.ImageIcon(getClass().getResource("/shubham/close.png"))); // NOI18N
        cut.setBorder(null);
        cut.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        cut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cutActionPerformed(evt);
            }
        });
        getContentPane().add(cut);
        cut.setBounds(950, 10, 40, 20);

        nm.setFont(new java.awt.Font("Segoe UI Light", 0, 24)); // NOI18N
        nm.setText("Hi, ");
        getContentPane().add(nm);
        nm.setBounds(50, 40, 240, 40);

        jLabel21.setFont(new java.awt.Font("Segoe UI Light", 0, 14)); // NOI18N
        jLabel21.setText("Welcome to Axis Bank. We have developed a user-friendly interface for you to get easy access.");
        getContentPane().add(jLabel21);
        jLabel21.setBounds(50, 70, 570, 40);

        jLabel22.setFont(new java.awt.Font("Segoe UI Light", 0, 14)); // NOI18N
        jLabel22.setText("You can perform your banking on a worry free environment. Make sure you log out after your work is over.");
        getContentPane().add(jLabel22);
        jLabel22.setBounds(50, 100, 650, 30);

        jLabel2.setFont(new java.awt.Font("Segoe UI Light", 0, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/shubham/accnt.jpg"))); // NOI18N
        jLabel2.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jLabel2.setOpaque(true);
        jLabel2.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        getContentPane().add(jLabel2);
        jLabel2.setBounds(60, 140, 910, 270);

        jLabel6.setBackground(new java.awt.Color(153, 153, 153));
        jLabel6.setFont(new java.awt.Font("Segoe UI Semibold", 1, 24)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText(" Account Balance");
        jLabel6.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel6.setOpaque(true);
        getContentPane().add(jLabel6);
        jLabel6.setBounds(70, 430, 190, 40);

        jLabel7.setBackground(new java.awt.Color(153, 153, 153));
        jLabel7.setFont(new java.awt.Font("Segoe UI Semibold", 1, 24)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText(" Account Balance");
        jLabel7.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel7.setOpaque(true);
        getContentPane().add(jLabel7);
        jLabel7.setBounds(70, 430, 190, 40);

        settings.setIcon(new javax.swing.ImageIcon(getClass().getResource("/shubham/sett.jpg"))); // NOI18N
        settings.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        settings.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                settingsMouseReleased(evt);
            }
        });
        getContentPane().add(settings);
        settings.setBounds(820, 40, 90, 70);

        Clock.setFont(new java.awt.Font("Segoe UI Light", 0, 20)); // NOI18N
        Clock.setForeground(new java.awt.Color(153, 0, 102));
        getContentPane().add(Clock);
        Clock.setBounds(740, 0, 140, 40);

        minimize.setText("_");
        minimize.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                minimizeActionPerformed(evt);
            }
        });
        getContentPane().add(minimize);
        minimize.setBounds(900, 10, 40, 20);

        drag.setBackground(new java.awt.Color(0, 0, 0));
        drag.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                dragMouseDragged(evt);
            }
        });
        drag.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                dragMousePressed(evt);
            }
        });
        getContentPane().add(drag);
        drag.setBounds(-10, 0, 1010, 40);

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/shubham/dev.jpg"))); // NOI18N
        jButton1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(717, 40, 90, 70);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void cutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cutActionPerformed
        int q = JOptionPane.showConfirmDialog(null, "Do you want to exit");
        if(q==JOptionPane.YES_OPTION)
        {System.exit(0);}
    }//GEN-LAST:event_cutActionPerformed

    private void log_outActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_log_outActionPerformed
        JOptionPane.showMessageDialog(this, "Logged out successfully!", "Logged out",1);
                
        new Face_1().setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_log_outActionPerformed

    private void settingsMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_settingsMouseReleased
    AnimationClass ac = new AnimationClass();
      {
        ac.jLabelXLeft(1000, 215, 10, 5, stt);
        ac.jButtonYUp(600, 385, 10, 5, updt_acc);
        ac.jButtonYUp(640, 385, 10, 5, acc_del);
        ac.jButtonYUp(680, 385, 10, 5, log_out);
        
      }
      {
        ac.jLabelXRight(215, 1000, 10, 5, stt);
        ac.jButtonYDown(385, 600, 10, 5, updt_acc);
        ac.jButtonYDown(385, 640, 10, 5, acc_del);
        ac.jButtonYDown(385, 680, 10, 5, log_out);
        
      }
    }//GEN-LAST:event_settingsMouseReleased

    private void transferMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_transferMouseReleased
        new Fund_Transfer(temp).setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_transferMouseReleased

    private void depositMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_depositMouseReleased
        new Fund_Deposit(temp).setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_depositMouseReleased

    private void wthdrwMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_wthdrwMouseReleased
        new Fund_Withdraw(temp).setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_wthdrwMouseReleased

    private void accbalMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_accbalMouseReleased
        new Check_Balance(temp).setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_accbalMouseReleased

    private void updt_accActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updt_accActionPerformed
        new Update_Details(temp).setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_updt_accActionPerformed

    private void acc_delActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_acc_delActionPerformed
        new Delete_Account(temp).setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_acc_delActionPerformed

    private void minimizeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_minimizeActionPerformed
        this.setState(Account.ICONIFIED);
    }//GEN-LAST:event_minimizeActionPerformed

    private void dragMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dragMouseDragged
        int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();
        this.setLocation(x-xM,y-yM);
    }//GEN-LAST:event_dragMouseDragged

    private void dragMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dragMousePressed
        xM=evt.getX();
        yM=evt.getY();
    }//GEN-LAST:event_dragMousePressed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
       new Developer().setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
for(double i = 0.0; i<=1.0; i+=0.1)
{
    String v = i+"F";
    float F = Float.valueOf(v);
    this.setOpacity(F);
    try
    {
        Thread.sleep(100);
    }
    catch(Exception e)
    {
        
    }
    
}
    }//GEN-LAST:event_formWindowOpened

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Account.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Account.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Account.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Account.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Account().setVisible(true);               
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Clock;
    private javax.swing.JButton acc_del;
    private javax.swing.JLabel accbal;
    private javax.swing.JButton cut;
    private javax.swing.JLabel deposit;
    private javax.swing.JLabel drag;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JButton log_out;
    private javax.swing.JButton minimize;
    private javax.swing.JLabel nm;
    private javax.swing.JButton settings;
    private javax.swing.JLabel stt;
    private javax.swing.JLabel transfer;
    private javax.swing.JButton updt_acc;
    private javax.swing.JLabel wthdrw;
    // End of variables declaration//GEN-END:variables
}
