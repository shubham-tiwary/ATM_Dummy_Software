
package shubham;
import AppPackage.AnimationClass;
import javax.swing.*;
import java.util.*;

public class Face_1 extends javax.swing.JFrame 
{
    int xM, yM;
    int timeRun = 0;

    public Face_1()
    {
        initComponents();
        
        new Thread()
        {
            @Override
            public void run()
            {
                while(timeRun==0)
                {
                    Calendar cal = new GregorianCalendar();
                    
                    
                    int hour = cal.get(Calendar.HOUR);
                    int min = cal.get(Calendar.MINUTE);
                    int sec = cal.get(Calendar.SECOND);
                    int ap = cal.get(Calendar.AM_PM);
                    String d = "",c = "",b = "",a = "";
                    if(ap==0) d="AM";else d="PM";
                    if(sec<10) c="0"+sec;else c=""+sec;
                    if(min<10) b="0"+min;else b=""+min;
                    if(hour<10) a="0"+hour;else a=""+hour;
                    if(hour==0) a="12";
                    
                    Clock.setText(""+a+":"+b+":"+c+" "+d);
                }
            }
        }.start();
    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        call_us = new javax.swing.JLabel();
        car_loan = new javax.swing.JLabel();
        mob_banking = new javax.swing.JLabel();
        mutual_funds = new javax.swing.JLabel();
        net_banking = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        TEXT5 = new javax.swing.JLabel();
        TEXT2 = new javax.swing.JLabel();
        TEXT3 = new javax.swing.JLabel();
        TEXT1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        register = new javax.swing.JButton();
        cut = new javax.swing.JButton();
        Axis_Logo = new javax.swing.JLabel();
        icon_img = new javax.swing.JLabel();
        log_in = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        picture = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        Clock = new javax.swing.JLabel();
        minimize = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBounds(new java.awt.Rectangle(200, 70, 0, 0));
        setMinimumSize(new java.awt.Dimension(1000, 600));
        setUndecorated(true);
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });
        getContentPane().setLayout(null);

        call_us.setIcon(new javax.swing.ImageIcon(getClass().getResource("/shubham/call.jpg"))); // NOI18N
        call_us.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        call_us.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                call_usMouseReleased(evt);
            }
        });
        getContentPane().add(call_us);
        call_us.setBounds(970, 170, 600, 380);

        car_loan.setIcon(new javax.swing.ImageIcon(getClass().getResource("/shubham/car_loan.jpg"))); // NOI18N
        car_loan.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        car_loan.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                car_loanMouseReleased(evt);
            }
        });
        getContentPane().add(car_loan);
        car_loan.setBounds(-290, 260, 310, 310);

        mob_banking.setIcon(new javax.swing.ImageIcon(getClass().getResource("/shubham/mobileapp.jpg"))); // NOI18N
        mob_banking.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        mob_banking.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                mob_bankingMouseReleased(evt);
            }
        });
        getContentPane().add(mob_banking);
        mob_banking.setBounds(690, 570, 260, 370);

        mutual_funds.setIcon(new javax.swing.ImageIcon(getClass().getResource("/shubham/mutualfund.jpg"))); // NOI18N
        mutual_funds.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        mutual_funds.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                mutual_fundsMouseReleased(evt);
            }
        });
        getContentPane().add(mutual_funds);
        mutual_funds.setBounds(370, 570, 260, 370);

        net_banking.setIcon(new javax.swing.ImageIcon(getClass().getResource("/shubham/netbanking.jpg"))); // NOI18N
        net_banking.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        net_banking.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                net_bankingMouseReleased(evt);
            }
        });
        getContentPane().add(net_banking);
        net_banking.setBounds(80, 570, 260, 370);

        jLabel5.setFont(new java.awt.Font("Segoe UI Light", 0, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(153, 0, 102));
        jLabel5.setText("AXIS CASHLESS CONTEST");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(750, 430, 140, 20);

        TEXT5.setFont(new java.awt.Font("Segoe UI Light", 0, 12)); // NOI18N
        TEXT5.setForeground(new java.awt.Color(153, 0, 102));
        TEXT5.setText("AXIS E-PAY");
        getContentPane().add(TEXT5);
        TEXT5.setBounds(750, 450, 80, 16);

        TEXT2.setFont(new java.awt.Font("Segoe UI Light", 0, 12)); // NOI18N
        TEXT2.setForeground(new java.awt.Color(153, 0, 102));
        TEXT2.setText("AXIS ZERO INTEREST HOME LOANS");
        getContentPane().add(TEXT2);
        TEXT2.setBounds(750, 390, 200, 20);

        TEXT3.setFont(new java.awt.Font("Segoe UI Light", 0, 12)); // NOI18N
        TEXT3.setForeground(new java.awt.Color(153, 0, 102));
        TEXT3.setText("INTERNATIONAL CASH CARDS");
        getContentPane().add(TEXT3);
        TEXT3.setBounds(750, 410, 180, 20);

        TEXT1.setFont(new java.awt.Font("Segoe UI Light", 0, 12)); // NOI18N
        TEXT1.setForeground(new java.awt.Color(153, 0, 102));
        TEXT1.setText("INTRODUCING -");
        getContentPane().add(TEXT1);
        TEXT1.setBounds(710, 360, 110, 30);

        jLabel3.setFont(new java.awt.Font("Segoe UI Light", 2, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(153, 0, 102));
        jLabel3.setText("Make it Happen");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(10, 200, 140, 30);

        jLabel4.setFont(new java.awt.Font("Segoe UI Light", 2, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(153, 0, 102));
        jLabel4.setText("Don't Wish");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(30, 170, 120, 30);

        register.setIcon(new javax.swing.ImageIcon(getClass().getResource("/shubham/openacc.png"))); // NOI18N
        register.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        register.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registerActionPerformed(evt);
            }
        });
        getContentPane().add(register);
        register.setBounds(740, 60, 200, 30);

        cut.setIcon(new javax.swing.ImageIcon(getClass().getResource("/shubham/close.png"))); // NOI18N
        cut.setBorder(null);
        cut.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        cut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cutActionPerformed(evt);
            }
        });
        getContentPane().add(cut);
        cut.setBounds(950, 10, 40, 20);

        Axis_Logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/shubham/logo.png"))); // NOI18N
        getContentPane().add(Axis_Logo);
        Axis_Logo.setBounds(20, 40, 200, 80);

        icon_img.setIcon(new javax.swing.ImageIcon(getClass().getResource("/shubham/icon.png"))); // NOI18N
        getContentPane().add(icon_img);
        icon_img.setBounds(10, 10, 20, 20);

        log_in.setFont(new java.awt.Font("Segoe UI Light", 0, 14)); // NOI18N
        log_in.setIcon(new javax.swing.ImageIcon(getClass().getResource("/shubham/login.png"))); // NOI18N
        log_in.setToolTipText("");
        log_in.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        log_in.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                log_inActionPerformed(evt);
            }
        });
        getContentPane().add(log_in);
        log_in.setBounds(600, 60, 120, 30);
        getContentPane().add(jSeparator1);
        jSeparator1.setBounds(0, 40, 1000, 20);

        picture.setIcon(new javax.swing.ImageIcon(getClass().getResource("/shubham/slide.gif"))); // NOI18N
        getContentPane().add(picture);
        picture.setBounds(0, 120, 810, 220);

        jLabel20.setFont(new java.awt.Font("Segoe UI Light", 0, 24)); // NOI18N
        jLabel20.setText("Bank Smart");
        getContentPane().add(jLabel20);
        jLabel20.setBounds(60, 350, 170, 40);

        jLabel21.setFont(new java.awt.Font("Segoe UI Light", 0, 14)); // NOI18N
        jLabel21.setText("Axis Bank offers a lot of ways to bank with apart from just Branch Banking.");
        getContentPane().add(jLabel21);
        jLabel21.setBounds(60, 380, 450, 40);

        jLabel22.setFont(new java.awt.Font("Segoe UI Light", 0, 14)); // NOI18N
        jLabel22.setText("Banking options like the Online Banking, Social Media Banking, Phone Banking are with you 24x7.");
        getContentPane().add(jLabel22);
        jLabel22.setBounds(60, 410, 590, 30);

        jLabel1.setFont(new java.awt.Font("Segoe UI Light", 2, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(153, 0, 102));
        jLabel1.setText("Progress with us...");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(160, 90, 120, 20);

        jLabel23.setFont(new java.awt.Font("Segoe UI Light", 0, 24)); // NOI18N
        jLabel23.setText("E-Payment");
        getContentPane().add(jLabel23);
        jLabel23.setBounds(60, 440, 170, 40);

        jLabel24.setFont(new java.awt.Font("Segoe UI Light", 0, 14)); // NOI18N
        jLabel24.setText("Axis Bank offers an Exciting range of online transactions to fulfill your financial needs.");
        getContentPane().add(jLabel24);
        jLabel24.setBounds(60, 470, 520, 40);

        jLabel25.setFont(new java.awt.Font("Segoe UI Light", 0, 14)); // NOI18N
        jLabel25.setText("Don't let the Demonetisation act affect your daily transactions");
        getContentPane().add(jLabel25);
        jLabel25.setBounds(60, 500, 660, 30);

        Clock.setFont(new java.awt.Font("Segoe UI Light", 0, 20)); // NOI18N
        Clock.setForeground(new java.awt.Color(153, 0, 102));
        getContentPane().add(Clock);
        Clock.setBounds(740, 0, 140, 40);

        minimize.setText("_");
        minimize.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                minimizeActionPerformed(evt);
            }
        });
        getContentPane().add(minimize);
        minimize.setBounds(900, 10, 40, 20);

        jLabel2.setBackground(new java.awt.Color(0, 0, 0));
        jLabel2.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                jLabel2MouseDragged(evt);
            }
        });
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jLabel2MousePressed(evt);
            }
        });
        getContentPane().add(jLabel2);
        jLabel2.setBounds(-10, 0, 1010, 40);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void cutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cutActionPerformed
int q = JOptionPane.showConfirmDialog(null, "Do you want to exit");
if(q==JOptionPane.YES_OPTION)
{System.exit(0);}
    }//GEN-LAST:event_cutActionPerformed

    private void log_inActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_log_inActionPerformed
        new Log_in().setVisible(true);
        this.setVisible(false);
       
    }//GEN-LAST:event_log_inActionPerformed

    private void registerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_registerActionPerformed
      new Register().setVisible(true);
      this.setVisible(false);  // TODO add your handling code here:
    }//GEN-LAST:event_registerActionPerformed

    private void car_loanMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_car_loanMouseReleased
      AnimationClass ac = new AnimationClass();
    ac.jLabelXRight(-290, 0, 10, 5, car_loan);
    ac.jLabelXLeft(0, -290, 10, 5, car_loan);
    }//GEN-LAST:event_car_loanMouseReleased

    private void mob_bankingMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mob_bankingMouseReleased
AnimationClass ac = new AnimationClass();
ac.jLabelYUp(570, 230, 10, 5, mob_banking);
ac.jLabelYDown(230, 570, 10, 5, mob_banking);
    }//GEN-LAST:event_mob_bankingMouseReleased

    private void mutual_fundsMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mutual_fundsMouseReleased
AnimationClass ac = new AnimationClass();
ac.jLabelYUp(570, 230, 10, 5, mutual_funds);
ac.jLabelYDown(230, 570, 10, 5, mutual_funds);
    }//GEN-LAST:event_mutual_fundsMouseReleased

    private void net_bankingMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_net_bankingMouseReleased
AnimationClass ac = new AnimationClass();
ac.jLabelYUp(570, 230, 10, 5, net_banking);
ac.jLabelYDown(230, 570, 10, 5, net_banking);
    }//GEN-LAST:event_net_bankingMouseReleased

    private void call_usMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_call_usMouseReleased
 AnimationClass ac = new AnimationClass();
    ac.jLabelXLeft(970, 200, 10, 5, call_us);
    ac.jLabelXRight(200, 970, 10, 5, call_us);
    }//GEN-LAST:event_call_usMouseReleased

    private void minimizeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_minimizeActionPerformed
        this.setState(Face_1.ICONIFIED);
    }//GEN-LAST:event_minimizeActionPerformed

    private void jLabel2MouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseDragged
int x = evt.getXOnScreen();
int y = evt.getYOnScreen();
this.setLocation(x-xM,y-yM);
    }//GEN-LAST:event_jLabel2MouseDragged

    private void jLabel2MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MousePressed
xM=evt.getX();
yM=evt.getY();
    }//GEN-LAST:event_jLabel2MousePressed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
for(double i = 0.0; i<=1.0; i+=0.1)
{
    String v = i+"F";
    float F = Float.valueOf(v);
    this.setOpacity(F);
    try
    {
        Thread.sleep(100);
    }
    catch(Exception e)
    {
        
    }
    
}
    }//GEN-LAST:event_formWindowOpened

    public static void main(String args[]) {

        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Face_1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Face_1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Face_1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Face_1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>


        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                
                try
                {
                    Thread.sleep(4500);
                }
                catch(Exception e)
                        {
                            
                        }
                
                new Face_1().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Axis_Logo;
    private javax.swing.JLabel Clock;
    private javax.swing.JLabel TEXT1;
    private javax.swing.JLabel TEXT2;
    private javax.swing.JLabel TEXT3;
    private javax.swing.JLabel TEXT5;
    private javax.swing.JLabel call_us;
    private javax.swing.JLabel car_loan;
    private javax.swing.JButton cut;
    private javax.swing.JLabel icon_img;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JButton log_in;
    private javax.swing.JButton minimize;
    private javax.swing.JLabel mob_banking;
    private javax.swing.JLabel mutual_funds;
    private javax.swing.JLabel net_banking;
    private javax.swing.JLabel picture;
    private javax.swing.JButton register;
    // End of variables declaration//GEN-END:variables
}
