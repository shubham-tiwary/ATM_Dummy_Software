1. Install the Rupee_Foradian font
2. Add the mysql connector
3. Add the Animation.jar
4. Ctrl+5 > Right Click on database > New Connection > 

Database URL - jdbc:mysql://localhost:3306/bank
Password - jermels

Mysql database - bank
table name - customer
 
+----------------+--------------+------+-----+---------+-------+
| Field          | Type         | Null | Key | Default | Extra |
+----------------+--------------+------+-----+---------+-------+
| FirstName      | varchar(15)  | NO   |     | NULL    |       |
| MiddleName     | varchar(15)  | YES  |     | NULL    |       |
| LastName       | varchar(15)  | NO   |     | NULL    |       |
| Gender         | varchar(6)   | NO   |     | NULL    |       |
| Father         | varchar(20)  | NO   |     | NULL    |       |
| Mother         | varchar(20)  | NO   |     | NULL    |       |
| Address        | varchar(100) | NO   |     | NULL    |       |
| DOB            | date         | NO   |     | NULL    |       |
| State		 | varchar(35)  | NO   |     | NULL    |       |
| Mobile         | int(10)      | NO   | UNI | NULL    |       |
| Pincode        | int(6)       | NO   |     | NULL    |       |
| Aadhar         | int(11)      | NO   | PRI | NULL    |       |
| Email          | varchar(50)  | NO   | UNI | NULL    |       |
| Account_num	 | int(11)	| NO   | UNI | NULL    |       |
| Username       | varchar(15)  | NO   | UNI | NULL    |       |
| Password       | varchar(25)  | NO   |     | NULL    |       |
| AccountBalance | int(11)      | NO   |     | NULL    |       |
+----------------+--------------+------+-----+---------+-------+

codes----


mysql>create database bank;
mysql>use bank;
mysql> create table customer (FirstName varchar (15) Not null, MiddleName varchar(15), LastName varchar (15) Not null, Gender varchar (6) not null, Father varchar (20) not null, Mother varchar (20) not null, Address varchar (100) not null,DOB date not null,State varchar(35) not null, Mobile int (10) not null unique, Pincode int (6) not null, Aadhar int(11) primary key, Email varchar (50) not null unique,Account_num int(11) not null unique, Username varchar (15) not null unique, Password varchar (25) not null, AccountBalance Double not null);
